var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'home' });
});

/* GET admin page. */
router.get('/admin', function(req, res, next) {
  res.render('admin', { title: 'admin' });
});

/* GET visitor page. */
router.get('/visitors', function(req, res, next) {
  res.render('visitors', { title: 'visitors' });
});

/* GET team main page. */
router.get('/teamMain', function(req, res, next) {
  res.render('teamMain', { title: 'Team Main' });
});

module.exports = router;
